#Install git

  #Install anaconda

#Check python

  ``` 
python --version 
```
  You should see something like
  ```
 Python 3.6.X:: Anaconda 4.X (64-bit)
 ```

#Create Environment
 ``` 
conda create -n ml-course python=3.6
activate ml-course 
```
#Install libraries  

```
 pip install wandb
 conda install -c conda-forge scikit-learn
 conda install -c conda-forge tensorflow 
conda install -c conda-forge keras 
```

#Clone this github repository
 ``` 
git clone
``` 
#Install necessary libraries within the python env
 ``` 
pip install -r requirements.txt
 ```

#Install Wandb
pip install pillow
pip install wandb

#Use Wandb
Login to your wandb account
wandb login accountId

##Enable Wandb in code

In wandb/.settings , specify the params
entity: test
project: deep-learning-training
base_url: https://api.wandb.ai

##Specify the WandbCallback to upload reports in web
callbacks=[WandbCallback(data_type="image",labels=labels)
