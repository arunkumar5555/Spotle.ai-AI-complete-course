import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM, SimpleRNN
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from keras.optimizers import SGD
import warnings

data = pd.read_csv("traffic_Data_1hr.csv")
# pd.read_csv("https://spotleai.sgp1.digitaloceanspaces.com/course/data/traffic_data_1hr_2013.csv")
print(data.shape)
print(data.head())
df = data['total_volume']
dataset = df.values.astype('float32')
dataset = np.reshape(dataset, (len(dataset),1))
plot_data = data[(data.month == 5) & (data.day <= 7)]
fig, ax = plt.subplots(figsize=(10,7))
plot_data.set_index('hr', inplace=True)
pt = plot_data.groupby('weekday')
['total_volume'].plot(legend=True)

scaler = MinMaxScaler(feature_range=(0, 1))
dataset = scaler.fit_transform(dataset)

train_size = int(len(dataset) * 0.70)
test_size = len(dataset) - train_size
train, test = dataset[0:train_size , :], dataset[train_size:len(dataset) , :]

def transform_dataset(dataset, look_back):
 dataX, dataY = [], []
 for i in range(len(dataset)-look_back-1):
  a = dataset[i:(i+look_back), 0]
  dataX.append(a)
  dataY.append(dataset[i + look_back, 0])
 return np.array(dataX), np.array(dataY)
look_back = 24
trainX, trainY = transform_dataset(train, look_back)
testX, testY = transform_dataset(test, look_back)

trainX = np.reshape(trainX, (trainX.shape[0], trainX.shape[1], 1))
testX = np.reshape(testX, (testX.shape[0], testX.shape[1], 1))

sgd=SGD(lr=0.1)

model = Sequential()
model.add(LSTM(1, input_shape=(look_back,1)))
model.add(Dense(1))

model.compile(loss='mean_squared_error', optimizer=sgd)
model.fit(trainX, trainY, epochs=10, batch_size=1, verbose=2)

trainPredict = model.predict(trainX)
testPredict = model.predict(testX)

trainPredict = scaler.inverse_transform(trainPredict)
trainY = scaler.inverse_transform([trainY])
testPredict = scaler.inverse_transform(testPredict)
testY = scaler.inverse_transform([testY])

# shift train predictions for plotting
trainPredictPlot = np.empty_like(dataset)
trainPredictPlot[:, :] = np.nan
trainPredictPlot[look_back:len(trainPredict)+look_back, :] = trainPredict
# shift test predictions for plotting
testPredictPlot = np.empty_like(dataset)
testPredictPlot[:, :] = np.nan
testPredictPlot[len(trainPredict)+(look_back*2)+1:len(dataset)-1, :] = testPredict

# plot baseline and predictions
plt.plot(scaler.inverse_transform(dataset))
plt.plot(trainPredictPlot)
plt.plot(testPredictPlot)
plt.xlim(2000, 3000)
plt.show()
